package uniconnect_backend.user.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @GetMapping("/api/users/test")
    public String test() {
        return "Protected endpoint accessed";
    }

    @GetMapping("/api/admin/test")
    @PreAuthorize("hasRole('ADMIN')")
    public String adminOnly() {
        return "Admin access granted";
    }

    @GetMapping("/api/provider/test")
    @PreAuthorize("hasRole('SERVICE_PROVIDER')")
    public String providerOnly() {
        return "Provider access granted";
    }

    @GetMapping("/api/customer/test")
    @PreAuthorize("hasRole('CUSTOMER')")
    public String customerOnly() {
        return "Customer access granted";
    }
}